package com.example.formulirfgd.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Participant(
    val nama: String,
    val telefon: String,
    val email: String,
    val gender: String,
    val skillset: List<String>,
    val kategori: String
) : Parcelable


/*

nim : 10122066
nama : Nurul Fithriani Zahra
kelas : andro 4
 */