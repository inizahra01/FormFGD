package com.example.formulirfgd

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.formulirfgd.databinding.ActivityDetailBinding
import com.example.formulirfgd.model.Participant

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val participant = intent.getParcelableExtra<Participant>("participant")

        participant?.let{
            binding.txtNamaResult.text = it.nama
            binding.txtTelefonResult.text = it.telefon
            binding.txtEmailResult.text = it.email
            binding.txtGenderResult.text = it.gender
            binding.txtSkillsetResult.text = it.skillset.joinToString(", ")
            binding.txtKategoriResult.text = it.kategori

        }

        binding.btnInfoDeveloper.setOnClickListener {
            val bottomSheetFragment = infoDeveloper()
            bottomSheetFragment.show(supportFragmentManager, "infoDeveloper")

        }

    }
}



/*

nim : 10122066
nama : Nurul Fithriani Zahra
kelas : andro 4
 */